- 项目配置：在安装好node和npm之后，在项目根目录运行命令行，输入指令npm i或者npm install安装项目所需模块。
- 项目运行：等待模块安装完毕，运行npm start指令即可运行项目，项目默认地址是localhost:8080。
- 项目修改：运行项目后，修改代码并保存，浏览器中展示的内容将自动更新。


常见问题：
1. 若安装模块时速度很慢，请尝试切换安装源（比如运行指令：npm config set registry https://registry.npmmirror.com），或拷贝别人已下好的node_modules文件夹。
2. vscode中可直接打开终端，运行指令。但有时vscode需要配置管理员权限，才能正常安装模块。
3. vscode中标签页右侧有圆点代表该文件有更新，未保存。